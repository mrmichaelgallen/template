### Team Projects
***

Team projects that I worked on while at The Tech Academy.

If you would like to see only my own solutions to software challenges, please check out my GitHub portfolio of my work with readme files detailing how I solved each one.

Return to [The Tech Academy Course Work](/The-Tech-Academy-Course-Work) main page
