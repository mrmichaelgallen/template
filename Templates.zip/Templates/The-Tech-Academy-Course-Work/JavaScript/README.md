### JavaScript Course Work
***

This is my course work for JavaScript, both following along drill work as well as my own solutions to assignment.

If you would like to see only my own solutions to software challenges, please check out my GitHub portfolio of my work with readme files detailing how I solved each one.

Return to course work [main page](../../../)
