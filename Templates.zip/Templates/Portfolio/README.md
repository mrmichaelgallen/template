### Portfolio
***

Write introduction

Check out my LinkedIn and my blog to learn more about me.

#### HTML & CSS
* [HTML & CSS  Examples](/Portfolio/HTML-CSS)
* [CSS Login Drill](/Portfolio/HTML-CSS/CSS-Login-Drill)

#### Database & SQL
* [Database & SQL Examples](/Portfolio/Database-SQL)
* [City Library Drill](/Portfolio/Database-SQL/City-Library-Drill)

#### JavaScript
* [JavaScript Examples](/Portfolio/JavaScript)
* [Login Script Drill](/Portfolio/JavaScript/Login-Script-Drill)

#### Python
* [Python Examples](/Portfolio/Python)
* [Datetime Drill](/Portfolio/Python/Datetime-Drill)

#### C#  
* [C# Examples](/Portfolio/C-Sharp)
* [File Transfer Drill](/Portfolio/C-Sharp/File-Transfer-Drill)

#### Team Projects
* Live-Project coming after C# Course
