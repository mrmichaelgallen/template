### Database & SQL Examples
***

A collection of Database & SQL examples of my work.

Please feel free to browse each project folder to learn about my approach to solving software problems. Each folder also contains a readme file that explains the project's objective, the approach I took to resolve the challenge and the result.

Return to [portfolio](../../../)

