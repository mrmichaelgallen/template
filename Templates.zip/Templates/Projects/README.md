### Projects and Ideas
***

A collection of projects and ideas that I want to work on.

